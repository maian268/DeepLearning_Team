# House Prices - MLP với PyTorch

**Deep Learning Lab 02**

## Cách mở bằng VS Code

1. Tải toàn bộ thư mục này về máy (hoặc giải nén file zip)
2. Mở VS Code → **File → Open Folder** → chọn thư mục này
3. Cài extension **Python** + **Jupyter** (nếu chưa có)
4. Mở terminal trong VS Code rồi chạy:

```bash
pip install -r requirements.txt
```

5. Mở file notebook:

```
notebooks/HousePrice_MLP_PyTorch.ipynb
```

6. Chọn kernel Python → chạy từng cell từ trên xuống.

---

## Cấu trúc thư mục

```
.
├── data/
│   ├── train.csv
│   ├── test.csv
│   └── sample_submission.csv
├── notebooks/
│   └── HousePrice_MLP_PyTorch.ipynb   ← Notebook chính (PyTorch)
├── experiments/                       ← Kết quả sẽ được lưu vào đây
│   └── mlp/
│       └── YYYYMMDD_HHMMSS/
│           ├── config.json
│           ├── metrics.json
│           ├── model.pt
│           └── predictions.csv
├── src/                               ← (tuỳ chọn) code sklearn cũ
├── requirements.txt
└── README.md
```

---

## Notebook chính làm gì?

- Load data + preprocessing gọn
- Xây MLP bằng **PyTorch**
- Tinh chỉnh siêu tham số (hidden size, learning rate, dropout…)
- Lưu kết quả đúng format `experiments/mlp/<timestamp>/`
- Xuất file `submission_mlp.csv` để nộp Kaggle

---

## Thành viên

- Mai Thị Thúy An (Leader)
- Trần Đoàn Phương Quyên
- Nguyễn Thị Phương Thanh
