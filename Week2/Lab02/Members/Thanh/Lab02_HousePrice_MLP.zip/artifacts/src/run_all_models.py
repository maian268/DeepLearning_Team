"""
Run hyperparameter tuning for Models 1, 2, 3 sequentially
and save results in experiments/ folders.
"""

from train_xgboost import main as train_xgb
from train_decision_tree import main as train_dt
from train_random_forest import main as train_rf


if __name__ == "__main__":
    print("\n>>> Starting Model 1: XGBoost")
    train_xgb()

    print("\n>>> Starting Model 2: Decision Tree")
    train_dt()

    print("\n>>> Starting Model 3: Random Forest")
    train_rf()

    print("\n=== All models finished. Check experiments/ folder ===")
