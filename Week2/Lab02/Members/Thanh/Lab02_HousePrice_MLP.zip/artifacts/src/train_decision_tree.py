"""
Model 2: Decision Tree Regressor with RandomizedSearchCV
Saves results under experiments/decision_tree/<timestamp>/
"""

import numpy as np
from sklearn.tree import DecisionTreeRegressor
from sklearn.model_selection import RandomizedSearchCV

from preprocess import preprocess
from experiment_utils import save_experiment


def main():
    print("=" * 60)
    print("MODEL 2: Decision Tree - Hyperparameter Tuning")
    print("=" * 60)

    x_train, y_train, df_test = preprocess()

    dt_model = DecisionTreeRegressor(random_state=42)

    param_distributions = {
        "max_depth": [3, 5, 10, 15, 20, None],
        "min_samples_split": [2, 5, 10, 20],
        "min_samples_leaf": [1, 2, 4, 8],
        "max_features": [None, "sqrt", "log2"],
    }

    search = RandomizedSearchCV(
        estimator=dt_model,
        param_distributions=param_distributions,
        n_iter=20,
        scoring="neg_mean_squared_error",
        cv=5,
        verbose=1,
        random_state=42,
        n_jobs=-1,
    )

    print("Starting RandomizedSearchCV ...")
    search.fit(x_train, y_train)

    best_model = search.best_estimator_
    best_params = search.best_params_
    best_score = search.best_score_

    cv_rmse = np.sqrt(-best_score)

    print("Best parameters:", best_params)
    print("Best CV score (neg MSE):", best_score)
    print("Approx CV RMSE:", cv_rmse)

    predictions = best_model.predict(df_test)

    metrics = {
        "best_cv_score_neg_mse": float(best_score),
        "best_cv_rmse": float(cv_rmse),
        "n_iter": 20,
        "cv_folds": 5,
        "scoring": "neg_mean_squared_error",
    }

    extra_config = {
        "param_distributions": param_distributions,
        "n_iter": 20,
        "cv": 5,
        "random_state": 42,
    }

    run_dir = save_experiment(
        model_name="decision_tree",
        model=best_model,
        best_params=best_params,
        metrics=metrics,
        predictions=predictions,
        extra_config=extra_config,
    )

    print("Done. Predictions shape:", predictions.shape)
    return run_dir


if __name__ == "__main__":
    main()
