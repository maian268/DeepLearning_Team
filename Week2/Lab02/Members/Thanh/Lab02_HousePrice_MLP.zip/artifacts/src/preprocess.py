"""
Preprocessing pipeline for House Prices dataset.
Matches the logic from the team's notebook.
"""

import pandas as pd
import numpy as np
from pathlib import Path

DATA_DIR = Path(__file__).resolve().parent.parent / "data"


def load_raw_data():
    train_df = pd.read_csv(DATA_DIR / "train.csv")
    test_df = pd.read_csv(DATA_DIR / "test.csv")
    return train_df, test_df


def fill_missing(train_df, test_df):
    # Train categorical
    cat_col_train = [
        "FireplaceQu", "GarageType", "GarageFinish", "MasVnrType",
        "BsmtQual", "BsmtCond", "BsmtExposure", "BsmtFinType1",
        "BsmtFinType2", "GarageQual", "GarageCond",
    ]
    ncat_col_train = ["LotFrontage", "GarageYrBlt", "MasVnrArea"]

    for col in cat_col_train:
        train_df[col] = train_df[col].fillna(train_df[col].mode()[0])
    for col in ncat_col_train:
        train_df[col] = train_df[col].fillna(train_df[col].mean())

    # Test categorical + numeric
    cat_col_test = [
        "FireplaceQu", "GarageType", "GarageFinish", "MasVnrType",
        "BsmtQual", "BsmtCond", "BsmtExposure", "BsmtFinType1",
        "BsmtFinType2", "GarageQual", "GarageCond", "MSZoning",
        "Utilities", "Exterior1st", "Exterior2nd", "KitchenQual",
        "Functional", "SaleType",
    ]
    ncat_col_test = [
        "LotFrontage", "GarageYrBlt", "MasVnrArea", "BsmtFinSF1",
        "BsmtFinSF2", "BsmtUnfSF", "TotalBsmtSF", "BsmtFullBath",
        "BsmtHalfBath", "GarageCars", "GarageArea",
    ]

    for col in cat_col_test:
        test_df[col] = test_df[col].fillna(test_df[col].mode()[0])
    for col in ncat_col_test:
        test_df[col] = test_df[col].fillna(test_df[col].mean())

    # Electrical (train only had 1 missing)
    train_df["Electrical"] = train_df["Electrical"].fillna(train_df["Electrical"].mode()[0])

    return train_df, test_df


def drop_columns(train_df, test_df):
    to_drop = ["Id", "Alley", "PoolQC", "Fence", "MiscFeature"]
    for k in to_drop:
        if k in train_df.columns:
            train_df.drop([k], axis=1, inplace=True)
        if k in test_df.columns:
            test_df.drop([k], axis=1, inplace=True)
    return train_df, test_df


def one_hot_encode(train_df, test_df):
    all_cat_col = [
        "MSZoning", "Street", "LotShape", "LandContour", "Utilities", "LotConfig",
        "LandSlope", "Neighborhood", "Condition1", "Condition2", "BldgType",
        "HouseStyle", "RoofStyle", "RoofMatl", "Exterior1st", "Exterior2nd",
        "MasVnrType", "ExterQual", "ExterCond", "Foundation", "BsmtQual",
        "BsmtCond", "BsmtExposure", "BsmtFinType1", "BsmtFinType2", "Heating",
        "HeatingQC", "CentralAir", "Electrical", "KitchenQual", "Functional",
        "FireplaceQu", "GarageType", "GarageFinish", "GarageQual", "GarageCond",
        "PavedDrive", "SaleType", "SaleCondition",
    ]

    final_df = pd.concat([train_df, test_df], axis=0)

    df_final = final_df.copy()
    for fields in all_cat_col:
        if fields not in final_df.columns:
            continue
        df1 = pd.get_dummies(final_df[fields], drop_first=True, prefix=fields)
        final_df.drop([fields], axis=1, inplace=True)
        df_final = pd.concat([df_final.drop(columns=[fields], errors="ignore"), df1], axis=1)

    # Remove duplicated columns
    df_final = df_final.loc[:, ~df_final.columns.duplicated()]

    # Split back
    df_train = df_final.iloc[:1460, :].copy()
    df_test = df_final.iloc[1460:, :].copy()

    if "SalePrice" in df_test.columns:
        df_test.drop(["SalePrice"], axis=1, inplace=True)

    return df_train, df_test


def get_features_targets(df_train, df_test):
    x_train = df_train.drop(["SalePrice"], axis=1)
    y_train = df_train["SalePrice"]
    # Ensure same columns / order
    df_test = df_test.reindex(columns=x_train.columns, fill_value=0)
    return x_train, y_train, df_test


def preprocess():
    """Full pipeline. Returns x_train, y_train, df_test (aligned features)."""
    train_df, test_df = load_raw_data()
    train_df, test_df = fill_missing(train_df, test_df)
    train_df, test_df = drop_columns(train_df, test_df)
    df_train, df_test = one_hot_encode(train_df, test_df)
    x_train, y_train, df_test = get_features_targets(df_train, df_test)

    # Convert bool (from get_dummies) to float for sklearn / xgboost compatibility
    x_train = x_train.astype(float)
    df_test = df_test.astype(float)

    print(f"x_train shape: {x_train.shape}")
    print(f"y_train shape: {y_train.shape}")
    print(f"df_test shape: {df_test.shape}")
    return x_train, y_train, df_test


if __name__ == "__main__":
    x_train, y_train, df_test = preprocess()
    print("Preprocessing done.")
