"""
Utilities for saving experiment results in the team's folder structure:

experiments/
  <model_name>/
    <YYYYMMDD_HHMMSS>/
      config.json
      metrics.json
      model.pkl
      predictions.csv
"""

import json
import joblib
from datetime import datetime
from pathlib import Path
import pandas as pd
import numpy as np

EXPERIMENTS_DIR = Path(__file__).resolve().parent.parent / "experiments"
DATA_DIR = Path(__file__).resolve().parent.parent / "data"


def create_run_dir(model_name: str) -> Path:
    """Create experiments/<model_name>/<timestamp>/ and return the path."""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    run_dir = EXPERIMENTS_DIR / model_name / timestamp
    run_dir.mkdir(parents=True, exist_ok=True)
    return run_dir


def save_config(run_dir: Path, config: dict):
    with open(run_dir / "config.json", "w", encoding="utf-8") as f:
        json.dump(config, f, indent=2, ensure_ascii=False, default=str)


def save_metrics(run_dir: Path, metrics: dict):
    with open(run_dir / "metrics.json", "w", encoding="utf-8") as f:
        json.dump(metrics, f, indent=2, ensure_ascii=False, default=str)


def save_model(run_dir: Path, model):
    joblib.dump(model, run_dir / "model.pkl")


def save_predictions(run_dir: Path, predictions: np.ndarray, sample_path: Path = None):
    if sample_path is None:
        sample_path = DATA_DIR / "sample_submission.csv"
    sub = pd.read_csv(sample_path)
    sub["SalePrice"] = predictions
    sub.to_csv(run_dir / "predictions.csv", index=False)


def save_experiment(
    model_name: str,
    model,
    best_params: dict,
    metrics: dict,
    predictions: np.ndarray,
    extra_config: dict = None,
) -> Path:
    """
    Full save: create folder + config + metrics + model + predictions.
    Returns the run directory path.
    """
    run_dir = create_run_dir(model_name)

    config = {
        "model_name": model_name,
        "best_params": best_params,
        "timestamp": run_dir.name,
    }
    if extra_config:
        config.update(extra_config)

    save_config(run_dir, config)
    save_metrics(run_dir, metrics)
    save_model(run_dir, model)
    save_predictions(run_dir, predictions)

    print(f"[OK] Experiment saved to: {run_dir}")
    return run_dir
