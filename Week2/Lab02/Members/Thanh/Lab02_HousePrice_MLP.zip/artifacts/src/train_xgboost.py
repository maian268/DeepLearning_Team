"""
Model 1: XGBoost Regressor with RandomizedSearchCV
Saves results under experiments/xgboost/<timestamp>/
"""

import numpy as np
from sklearn.model_selection import RandomizedSearchCV
from sklearn.metrics import mean_squared_error
import xgboost as xgb

from preprocess import preprocess
from experiment_utils import save_experiment


def main():
    print("=" * 60)
    print("MODEL 1: XGBoost - Hyperparameter Tuning")
    print("=" * 60)

    x_train, y_train, df_test = preprocess()

    xgb_model = xgb.XGBRegressor(random_state=42, n_jobs=1)

    param_distributions = {
        "n_estimators": [100, 500, 900, 1100, 1500],
        "max_depth": [2, 3, 5, 10, 15],
        "learning_rate": [0.05, 0.1, 0.15, 0.2],
        "min_child_weight": [1, 2, 3, 4],
        "booster": ["gbtree", "gblinear"],
        "base_score": [0.25, 0.5, 0.75, 1],
    }

    # Keep n_iter reasonable for runtime (notebook used 10)
    search = RandomizedSearchCV(
        estimator=xgb_model,
        param_distributions=param_distributions,
        n_iter=5,
        scoring="neg_mean_squared_error",
        cv=5,
        verbose=1,
        return_train_score=True,
        random_state=42,
        n_jobs=1,
    )

    print("Starting RandomizedSearchCV ...")
    search.fit(x_train, y_train)

    best_model = search.best_estimator_
    best_params = search.best_params_
    best_score = search.best_score_  # neg MSE

    # CV RMSE approximation
    cv_rmse = np.sqrt(-best_score)

    print("Best parameters:", best_params)
    print("Best CV score (neg MSE):", best_score)
    print("Approx CV RMSE:", cv_rmse)

    # Predict on test
    predictions = best_model.predict(df_test)

    metrics = {
        "best_cv_score_neg_mse": float(best_score),
        "best_cv_rmse": float(cv_rmse),
        "n_iter": 5,
        "cv_folds": 5,
        "scoring": "neg_mean_squared_error",
    }

    extra_config = {
        "param_distributions": param_distributions,
        "n_iter": 5,
        "cv": 5,
        "random_state": 42,
    }

    run_dir = save_experiment(
        model_name="xgboost",
        model=best_model,
        best_params=best_params,
        metrics=metrics,
        predictions=predictions,
        extra_config=extra_config,
    )

    print("Done. Predictions shape:", predictions.shape)
    return run_dir


if __name__ == "__main__":
    main()
